This is the API used in the "Consuming an API" part of the book and it is intended for educational use only.

Contains everything you need to use this API and an installation script for faster implementation.

This API is built with [Laravel](http://laravel.com)
