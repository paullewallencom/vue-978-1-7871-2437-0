This is the API used in the "Consuming an API" part of the book, in its homework section and it is intended for educational use.

By running the following command you will get a database filled with dummy data and a fully functional API.

```bash
sh setup.sh
```

Then you will be able to access the site on `http://localhost:3000`.

This API is built with [Laravel](http://laravel.com)
