# Workflow Automation with Gulp

To run it locally you have to run:

```bash
npm install
gulp watch
```
