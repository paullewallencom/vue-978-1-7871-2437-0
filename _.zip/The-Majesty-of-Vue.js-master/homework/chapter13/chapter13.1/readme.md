# Compiling ES6 with Babel

To run it locally you have to run:

```bash
npm install
npm run build
```
